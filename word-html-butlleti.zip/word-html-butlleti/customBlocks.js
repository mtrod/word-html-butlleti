function addCustomBlocks(editor) {
  // -------------------------
  // Ensure there is an "options" panel.
  // -------------------------
  let optionsPanel = editor.Panels.getPanel('options');
  if (!optionsPanel) {
    const panelEl = document.createElement('div');
    panelEl.className = 'panel__top';
    document.body.insertBefore(panelEl, document.body.firstChild);
    optionsPanel = editor.Panels.addPanel({
      id: 'options',
      el: panelEl,
    });
  }

  // -------------------------
  // Define Custom Blocks
  // -------------------------
  editor.BlockManager.add('intro-block', {
    label: 'Bloc introducció',
    content: `<h2 class="ew-h2">Hola, [TERCERSNOMBRESINAPELLIDOS]! <img alt="" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/1f44b/32.png" style="width:4%"></h2>
<p class="ew-textbase">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<p class="ew-textbase">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('dates-block', {
    label: 'Bloc 2 columnes',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<h2 class="ew-h2" style="color:#000078;font-size:22px;font-family:Arial,sans-serif;line-height:26px;font-weight:bold;margin:4px 0 1em 0">Apunta't aquestes dates!</h2>
<table border="0" cellpadding="1" cellspacing="1" style="width:100%">
  <tbody>
    <tr>
      <td valign="top" style="background-color:#d6faff;width:50%;background-image:url('https://campus.uoc.edu/estudiant/_resources/img/mail/uoc_blau_birret_butlleti.png');background-position:right bottom 5px;background-repeat:no-repeat;margin-top:0;padding:20px 60px 20px 20px;border-right:2px solid white">
        <div>
          <h3 style="color:#000078;font-size:20px;font-family:Arial,sans-serif;line-height:20px;font-weight:bold;margin:0 0 20px 0">Dates acadèmiques</h3>
          <p>12 de març - <strong>Inici de semestre</strong>: màsters universitaris i programes de formació permanent</p>
          <p>1 i 2 de juliol - <strong>Notes finals</strong> de graus, màsters universitaris i programes de formació permanent</p>
        </div>
      </td>
      <td valign="top" style="background-color:#d6faff;width:50%;background-image:url('https://campus.uoc.edu/estudiant/_resources/img/mail/uoc_blau_calendari_i_agenda_butlleti.png');background-position:right bottom 5px;background-repeat:no-repeat;margin-top:0;padding:20px 60px 20px 20px;border-left:2px solid white">
        <div>
          <h3 style="color:#000078;font-size:20px;font-family:Arial,sans-serif;line-height:20px;font-weight:bold;margin:0 0 20px 0">Actes i seminaris</h3>
          <p>12 de març - <a href="https://uoc.jobteaser.com/ca/events/242488" target="_blank" style="text-decoration:underline;color:#000078">Coneix els <strong>Serveis de Carrera Professional i Ocupació</strong> de la UOC</a> (en línia)</p>
          <p>27 de març - <a href="https://symposium.uoc.edu/129829/detail/la-importancia-de-les-soft-skills-en-el-mercat-laboral-actual-un-factor-clau-de-desenvolupament.html" target="_blank" style="text-decoration:underline;color:#000078">La importància de les <strong>soft skills en el mercat laboral</strong> actual</a> (presencial)</p>
        </div>
      </td>
    </tr>
  </tbody>
</table>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('noticies-block', {
    label: 'Bloc 4 columnes (notícies)',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<h2 class="ew-h2" style="color:#000078;font-size:22px;font-family:Arial,sans-serif;line-height:26px;font-weight:bold;margin:4px 0 1em 0;">Tens 5 minuts més?</h2>
<table border="0" cellpadding="1" cellspacing="1" style="width:100%;color:#000078;font-family:Arial, sans-serif;font-size:16px;line-height:145%;">
  <tr>
    <td valign="top" style="width:25%;">
      <img alt="" src="https://via.placeholder.com/150" style="width:100%;" /><br>
      <div style="padding:10px 0;">
        <a href="#" style="text-decoration:underline;color:#000078;word-break:break-word;" target="_blank">Placeholder News Title 1</a>
      </div>
    </td>
    <td valign="top" style="width:25%;">
      <img alt="" src="https://via.placeholder.com/150" style="width:100%;" /><br>
      <div style="padding:10px 0;">
        <a href="#" style="text-decoration:underline;color:#000078;word-break:break-word;" target="_blank">Placeholder News Title 2</a>
      </div>
    </td>
    <td valign="top" style="width:25%;">
      <img alt="" src="https://via.placeholder.com/150" style="width:100%;" /><br>
      <div style="padding:10px 0;">
        <a href="#" style="text-decoration:underline;color:#000078;word-break:break-word;" target="_blank">Placeholder News Title 3</a>
      </div>
    </td>
    <td valign="top" style="width:25%;">
      <img alt="" src="https://via.placeholder.com/150" style="width:100%;" /><br>
      <div style="padding:10px 0;">
        <a href="#" style="text-decoration:underline;color:#000078;word-break:break-word;" target="_blank">Placeholder News Title 4</a>
      </div>
    </td>
  </tr>
</table>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('premis-block', {
    label: 'Bloc 3 columnes',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<h2 class="ew-h2" style="color:#000078;font-size:22px;font-family:Arial,sans-serif;line-height:26px;font-weight:bold;margin:4px 0 1em 0;">Premis, beques i ajuts</h2>
<table border="0" cellpadding="10" cellspacing="3" style="width:100%">
  <tr>
    <td valign="top" style="width:33%; background-color:#d6faff;">
      <p><a href="#" style="text-decoration:underline;color:#000078;" target="_blank"><strong>Placeholder 1</strong></a>
      <br>Deadline: Placeholder Date</p>
    </td>
    <td valign="top" style="width:33%; background-color:#d6faff;">
      <p><a href="#" style="text-decoration:underline;color:#000078;" target="_blank"><strong>Placeholder 2</strong></a>
      <br>Deadline: Placeholder Date</p>
    </td>
    <td valign="top" style="width:33%; background-color:#d6faff;">
      <p><a href="#" style="text-decoration:underline;color:#000078;" target="_blank"><strong>Placeholder 3</strong></a>
      <br>Deadline: Placeholder Date</p>
    </td>
  </tr>
</table>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('comparteix-block', {
    label: 'Comparteix amb la comunitat',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<table border="0" cellpadding="1" cellspacing="1" style="width:100%">
  <tbody>
    <tr>
      <td valign="top" style="width:70%">
        <h2 class="ew-h2">Comparteix amb la comunitat</h2>
        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSfO_aYtJVhwJFKxUsK9F2DlsZ5wVh5c5oazfhcgidf8MYRs4w/viewform?usp=send_form" style="text-decoration:none;color:#ffffff">
          <table width="300" border="0" cellspacing="0" cellpadding="4" height="40">
            <tbody>
              <tr>
                <td align="center" valign="middle" style="background-color:#000078;font-size:16px;color:#ffffff">
                  Fes-nos arribar la teva notícia
                </td>
              </tr>
            </tbody>
          </table>
        </a>
        <p class="ew-textbase"><br><img alt="" src="https://campus.uoc.edu/estudiant/_resources/img/mail/uoc_blau_escriu.png" style="width:4%"> Tens un projecte cultural o solidari? Necessites compartir una enquesta per al teu treball final? <strong><a href="https://campus.uoc.edu/estudiant/mes-uoc/ca/actualitat/noticies/tens-una-noticia/index.html" style="text-decoration:underline;color:#000078" target="_blank">Consulta les bases per publicar el teu missatge</a></strong></p>
      </td>
    </tr>
  </tbody>
</table>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('feedback-block', {
    label: 'Feedback Qualtrics',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<h2 class="ew-h2">Què t'ha semblat el butlletí?</h2>
<p><a href="https://uocuniwide.eu.qualtrics.com/jfe/form/SV_bvb2J1rVTyfQdgi" target="_blank"><img alt="" src="https://campus.uoc.edu/estudiant/_resources/img/novetats/butlleti/Valoracix_CA.png" style="width:75%" /></a></p>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('h2section-block', {
    label: 'Títol de secció amb filet',
    content: `
<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<h2 class="ew-h2">Placeholder section</h2>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('ptext-block', {
    label: 'Bloc de text',
    content: `<p class="ew-textbase">Placeholder text</p>`,
    category: 'Català'
  });
  
  editor.BlockManager.add('imagetext-block', {
    label: 'Filet, imatge i text',
    content: `<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">
<p><a href="https://www.youtube.com/watch?v=0Wx-EWtWpT4" style="text-decoration:none;color:#000078" target="_blank"><img alt="" src="https://campus.uoc.edu/estudiant/_resources/img/novetats/butlleti/0703_pla_llengues_CA.jpg" style="width:100%" /></a>
<br>Placeholder text under image with link.</p>`,
    category: 'Català'
  });
  
  // -------------------------
  // Register a custom component type for "h2section-block"
  // -------------------------
  editor.DomComponents.addType('h2section-block', {
    model: {
      defaults: {
        tagName: 'div',
        components: [
          '<hr width="100%" size="3" color="#000078" style="margin:2rem 0 0 0">',
          {
            tagName: 'h2',
            classes: ['ew-h2'],
            components: 'Placeholder section'
          }
        ],
        attributes: { 'data-title': 'Placeholder section' }
      },
      init() {
        this.on('change:attributes:data-title', this.updateTitle);
      },
      updateTitle() {
        const title = this.getAttributes()['data-title'] || 'Placeholder section';
        const comps = this.get('components');
        if (comps && comps.models && comps.models[1]) {
          comps.models[1].set('components', title);
        }
      }
    },
    view: {}
  });
  
  // -------------------------
  // Add custom command to open the template selector modal.
  // -------------------------
  editor.Commands.add('open-template-selector', {
    run: (editor) => {
      // Set modal title and content.
      editor.Modal.setTitle("Seleccionar plantilla base");
      editor.Modal.setContent(`
        <div id="template-selector-modal" style="padding: 10px;">
          <p>Seleccionar plantilla base:</p>
          <label><input type="radio" name="baseTemplate" value="catalan" checked>Plantilla en català</label><br>
          <label><input type="radio" name="baseTemplate" value="spanish">Plantilla en castellà</label><br>
          <label><input type="radio" name="baseTemplate" value="english">Plantilla en anglès</label><br><br>
          <button id="template-select-submit">Aplicar plantilla</button>
        </div>
      `);
      editor.Modal.open();
      
      setTimeout(() => {
        const btn = document.getElementById("template-select-submit");
        if (btn) {
          btn.addEventListener("click", () => {
            const selected = document.querySelector('input[name="baseTemplate"]:checked').value;
            if (baseTemplates[selected]) {
              if (confirm("Canviar de plantilla base resetejarà els continguts. Continuar?")) {
                editor.setComponents(baseTemplates[selected].replace('{{content}}', ''));
              }
            }
            editor.Modal.close();
          });
        }
      }, 0);
    }
  });
  
  // -------------------------
  // Add custom command to open modal for DOCX upload.
  // -------------------------
  editor.Commands.add('custom-action', {
    run: (editor, sender) => {
      editor.Modal.setTitle("Upload DOCX");
      editor.Modal.setContent(`
        <div id="docx-modal-content">
          <h2>Upload DOCX File</h2>
          <input type="file" id="docxFileModal" accept=".docx" />
          <br>
          <button id="uploadDocxBtn">Upload and Process</button>
        </div>
      `);
      editor.Modal.open();
      setTimeout(() => {
        const btn = document.getElementById('docxFileModal') ? document.getElementById('uploadDocxBtn') : null;
        if (btn) {
          btn.addEventListener('click', () => {
            handleDocxUploadModal();
            editor.Modal.close();
          });
        }
      }, 0);
      sender && sender.set('active', false);
    }
  });
  
  // -------------------------
  // Add custom buttons to the "options" panel.
  // -------------------------
  editor.Panels.addButton('options', [{
    id: 'template-selector-button',
    label: '<i class="fa fa-file-text-o"></i>',
    command: 'open-template-selector',
    attributes: { title: 'Seleccionar plantilla base', 'data-tooltip-pos': 'bottom' }
  }]);
  
  editor.Panels.addButton('options', [{
    id: 'custom-button',
    label: '<i class="fa fa-upload"></i>',
    command: 'custom-action',
    attributes: { title: 'Click to upload DOCX and process it', 'data-tooltip-pos': 'bottom' }
  }]);
}
